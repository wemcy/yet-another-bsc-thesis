<template>
    <div
        class="min-h-screen flex flex-col items-center justify-center text-center text-gray-700 px-4"
    >
        <h1 class="text-6xl font-bold text-blue-600 mb-4">404</h1>
        <p class="text-xl mb-6">A keresett oldal nem található.</p>
        <router-link to="/" class="text-blue-600 hover:underline">Vissza a főoldalra</router-link>
    </div>
</template>
