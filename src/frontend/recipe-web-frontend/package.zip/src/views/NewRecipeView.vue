<template>
    <main class="max-w-4xl mx-auto px-4 py-10 text-gray-800">
        <h1 class="text-3xl font-bold mb-6 text-center">Új recept hozzáadása</h1>
        <RecipeForm />
    </main>
</template>

<script setup lang="ts">
import RecipeForm from '@/components/recipe/RecipeForm.vue'
</script>
