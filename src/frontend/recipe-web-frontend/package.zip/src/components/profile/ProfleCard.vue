<template>
    <section class="flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-10">
        <img
            src="@/assets/profile.svg"
            alt="Profilkép"
            class="w-32 h-32 rounded-full object-cover"
        />
        <div class="text-center sm:text-left">
            <h1 class="text-2xl font-bold">Kovács Anna</h1>
            <p class="text-gray-600">anna.kovacs@example.com</p>
        </div>
    </section>
</template>
