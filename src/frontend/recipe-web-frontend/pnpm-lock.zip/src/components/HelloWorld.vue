<script setup lang="ts"></script>

<template>
    <div class="text-3xl font-bold underline"></div>
</template>

<style scoped></style>
